namespace BaiTap;

// Lớp đa thức P(x) = a0 + a1.x + ... + an.x^n
public class DaThuc
{
    // Danh sách các đơn thức trong đa thức
    private List<DonThuc> ds = new List<DonThuc>();

    // Constructor mặc định
    public DaThuc() { }

    // Constructor tạo đa thức có bậc cho trước
    public DaThuc(int bac)
    {
        // Tạo các đơn thức từ bậc 0 đến bậc bac
        for (int i = 0; i <= bac; i++)
            ds.Add(new DonThuc(0, i));
    }

    // Constructor tạo đa thức từ mảng hệ số
    public DaThuc(double[] heSo)
    {
        // Mỗi phần tử trong mảng là một hệ số
        for (int i = 0; i < heSo.Length; i++)
            ds.Add(new DonThuc(heSo[i], i));
    }

    // Constructor sao chép một đa thức khác
    public DaThuc(DaThuc other)
    {
        // Sao chép từng đơn thức
        foreach (var d in other.ds)
            ds.Add(new DonThuc(d.A, d.N));
    }

    // Lấy bậc của đa thức
    public int Bac => ds.Count - 1;

    // Indexer dùng để truy cập đơn thức theo vị trí
    public DonThuc this[int i]
    {
        get => ds[i];
        set => ds[i] = value;
    }

    // Nhập đa thức
    public void Input()
    {
        int n;

        // Nhập bậc n và yêu cầu n >= 0
        do
        {
            n = Helper.ReadInt("Bậc n của đa thức (>= 0): ");
        }
        while (n < 0);

        // Xóa danh sách cũ
        ds.Clear();

        // Nhập các hệ số từ a0 đến an
        for (int i = 0; i <= n; i++)
            ds.Add(new DonThuc(Helper.ReadDouble($"  Hệ số a{i}: "), i));
    }

    // Xuất đa thức ra màn hình
    public void Output() => Console.WriteLine("P(x) = " + this);

    // Chuyển đa thức thành chuỗi
    public override string ToString() => string.Join(" + ", ds);

    // Tính giá trị của đa thức tại x
    public double TinhGiaTri(double x)
    {
        double s = 0;

        // Tính giá trị từng đơn thức rồi cộng lại
        foreach (var d in ds)
            s += d.TinhGiaTri(x);

        return s;
    }
}

// Lớp thực hiện bài 2_3b
public static class Bai2_3b
{
    public static void Run()
    {
        // Tạo một đa thức mới
        DaThuc p = new DaThuc();

        // Nhập đa thức
        p.Input();

        // Xuất đa thức
        p.Output();

        // Kiểm tra đa thức có đơn thức hay không
        if (p.Bac >= 0)
            Console.WriteLine($"Đơn thức thứ 0 (indexer) = {p[0]}");

        // Nhập giá trị x
        double x = Helper.ReadDouble("Nhập x: ");

        // Tính và xuất giá trị P(x)
        Console.WriteLine($"P({x}) = {p.TinhGiaTri(x)}");
    }
}