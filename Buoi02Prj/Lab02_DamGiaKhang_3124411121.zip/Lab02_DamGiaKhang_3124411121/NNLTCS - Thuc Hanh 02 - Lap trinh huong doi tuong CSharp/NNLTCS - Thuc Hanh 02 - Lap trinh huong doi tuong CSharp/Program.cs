using System.Text;
namespace BaiTap;

public static class Program
{
    public static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        var menu = new List<(string Ten, Action Chay)>
        {
            ("Bài 1.1 - Tính tuổi sinh viên",            Bai1_1.Run),
            ("Bài 1.2 - Lớp Point",                       Bai1_2.Run),
            ("Bài 1.3 - Lớp Person",                      Bai1_3.Run),
            ("Bài 1.4 - Lớp Phân số",                     Bai1_4.Run),
            ("Bài 1.5 - Lớp Đơn thức",                    Bai1_5.Run),
            ("Bài 2.1 - ArrayPoint",                      Bai2_1.Run),
            ("Bài 2.2 - PersonList",                      Bai2_2.Run),
            ("Bài 2.3 - Dãy số (mảng 1 chiều)",           Bai2_3.Run),
            ("Bài 2.4 - Mảng 2 chiều",                    Bai2_4.Run),
            ("Bài 2.3 (b) - Đa thức",                     Bai2_3b.Run),
            ("Bài 2.4 (b) - Dãy phân số",                 Bai2_4b.Run),
            ("Bài 2.5 - Tính lương phòng ban",            Bai2_5.Run),
            ("Bài 3.1 - Array.Sort với IComparable",      Bai3_1.Run),
            ("Bài 3.2 - Sắp xếp tổng quát bằng interface",Bai3_2.Run),
            ("Bài 3.3 - Sắp xếp tổng quát bằng delegate", Bai3_3.Run),
            ("Bài 3.4* - ConsoleMenu (giải PT bậc 2)",    Bai3_4.Run),
            ("Bài 3.5 - Tính lương nhân viên (kế thừa)",  Bai3_5.Run),
            ("Bài 3.6 - Tính điểm thí sinh",              Bai3_6.Run),
        };

        while (true)
        {
            Console.WriteLine("\n========== MENU BÀI TẬP OOP C# ==========");
            for (int i = 0; i < menu.Count; i++)
                Console.WriteLine($"{i + 1,2}. {menu[i].Ten}");
            Console.WriteLine(" 0. Thoát");
            int c = Helper.ReadInt("Chọn bài: ");
            if (c == 0) break;
            if (c < 1 || c > menu.Count) { Console.WriteLine("Lựa chọn không hợp lệ."); continue; }

            Console.WriteLine($"\n--- {menu[c - 1].Ten} ---");
            try { menu[c - 1].Chay(); }
            catch (Exception ex) { Console.WriteLine("Lỗi: " + ex.Message); }
        }
    }
}
