using System.Collections;
namespace BaiTap;

// Lớp quản lý danh sách các điểm (Point) sử dụng ArrayList
public class ArrayPoint
{
    private ArrayList list = new ArrayList();

    // Thuộc tính trả về số lượng điểm trong danh sách
    public int Count => list.Count;

    // Chỉ mục (Indexer) để truy xuất hoặc gán điểm theo vị trí i
    public Point this[int i]
    {
        get => (Point)list[i];
        set => list[i] = value;
    }

    // Thêm một điểm vào danh sách
    public void Add(Point p) => list.Add(p);

    // Nhập danh sách các điểm từ bàn phím
    public void Input()
    {
        int n = Helper.ReadInt("Số lượng điểm: ");
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Điểm thứ {i}:");
            Point p = new Point();
            p.Input();
            list.Add(p);
        }
    }

    // Xuất danh sách các điểm ra màn hình
    public void Output()
    {
        for (int i = 0; i < list.Count; i++)
            Console.WriteLine($"  [{i}] {this[i]}");
    }
}

// Lớp chạy thử nghiệm (Bài 2.1)
public static class Bai2_1
{
    public static void Run()
    {
        ArrayPoint ds = new ArrayPoint();
        ds.Input();
        Console.WriteLine("Danh sách điểm:");
        ds.Output();
        
        // Cho phép người dùng nhập chỉ số để truy xuất điểm bất kỳ
        if (ds.Count > 0)
        {
            int i = Helper.ReadInt($"Truy cập điểm thứ i (0..{ds.Count - 1}): ");
            if (i >= 0 && i < ds.Count) Console.WriteLine($"Điểm thứ {i} = {ds[i]}");
            else Console.WriteLine("Chỉ số ngoài phạm vi.");
        }
    }
}