namespace BaiTap;

// Lớp menu tổng quát
public class ConsoleMenu
{
    // Mảng lưu tên các chức năng
    private readonly string[] chucNang;

    // Sự kiện được gọi khi người dùng chọn chức năng
    public event Action<int> Choose;

    // Constructor nhận danh sách chức năng
    public ConsoleMenu(params string[] chucNang)
    {
        this.chucNang = chucNang;
    }

    // Xử lý khi người dùng chọn chức năng
    protected virtual void OnChoose(int x) =>
        Choose?.Invoke(x);

    // Hiển thị và xử lý menu
    public void Start()
    {
        while (true)
        {
            // Hiển thị menu
            Console.WriteLine("\nMenu");

            // Hiển thị các chức năng
            for (int i = 0; i < chucNang.Length; i++)
                Console.WriteLine($"{i + 1}. {chucNang[i]}");

            // Hiển thị lựa chọn thoát
            Console.WriteLine("0. Thoát chương trình");

            // Nhập chức năng cần thực hiện
            int x = Helper.ReadInt("Thực hiện: ");

            // Nếu chọn 0 thì thoát menu
            if (x == 0) break;

            // Kiểm tra chức năng có hợp lệ không
            if (x < 1 || x > chucNang.Length)
            {
                Console.WriteLine("Chức năng không tồn tại.");
                continue;
            }

            // Thông báo chức năng được chọn
            Console.WriteLine($"Bạn thực hiện chức năng {x}");

            // Gọi hàm xử lý chức năng
            OnChoose(x);
        }
    }
}


// Lớp menu giải phương trình bậc 2
public class PTBac2Console : ConsoleMenu
{
    // Các hệ số của phương trình
    private double a, b, c;

    // Constructor tạo menu với 2 chức năng
    public PTBac2Console()
        : base("Nhập hệ số a, b, c", "Giải phương trình bậc 2") { }

    // Xử lý chức năng được chọn
    protected override void OnChoose(int x)
    {
        switch (x)
        {
            // Chức năng 1: nhập hệ số
            case 1:
                a = Helper.ReadDouble("  a = ");
                b = Helper.ReadDouble("  b = ");
                c = Helper.ReadDouble("  c = ");
                break;

            // Chức năng 2: giải phương trình
            case 2:
                Giai();
                break;
        }

        // Gọi sự kiện Choose cho các đối tượng đã đăng ký
        base.OnChoose(x);
    }

    // Hàm giải phương trình bậc 2
    private void Giai()
    {
        // Trường hợp a = 0
        if (a == 0)
        {
            // Nếu b = 0 thì phương trình có thể vô số hoặc vô nghiệm
            if (b == 0)
                Console.WriteLine(
                    c == 0 ? "Vô số nghiệm" : "Vô nghiệm"
                );

            // Trường hợp phương trình bậc 1
            else
                Console.WriteLine($"Phương trình bậc 1, x = {-c / b}");

            return;
        }

        // Tính delta
        double d = b * b - 4 * a * c;

        // Delta < 0: vô nghiệm
        if (d < 0)
            Console.WriteLine("Vô nghiệm");

        // Delta = 0: nghiệm kép
        else if (d == 0)
            Console.WriteLine($"Nghiệm kép x = {-b / (2 * a)}");

        // Delta > 0: có hai nghiệm
        else
        {
            Console.WriteLine($"x1 = {(-b + Math.Sqrt(d)) / (2 * a)}");
            Console.WriteLine($"x2 = {(-b - Math.Sqrt(d)) / (2 * a)}");
        }
    }
}


// Lớp thực hiện bài 3_4
public static class Bai3_4
{
    public static void Run()
    {
        // Tạo menu giải phương trình bậc 2
        PTBac2Console app = new PTBac2Console();

        // Đăng ký sự kiện Choose
        app.Choose += x =>
            Console.WriteLine(
                $"[Sự kiện Choose] chức năng {x} đã được xử lý"
            );

        // Bắt đầu chạy menu
        app.Start();
    }
}