using System;
using System.Collections.Generic;

namespace BaiTap;

// Lớp quản lý mảng số nguyên (dãy số)
public class DaySo
{
    private int[] a;

    // Các hàm khởi tạo (mặc định, theo kích thước, từ mảng có sẵn và copy constructor)
    public DaySo() { a = new int[0]; }
    public DaySo(int n) { a = new int[n < 0 ? 0 : n]; }
    public DaySo(int[] arr) { a = (int[])arr.Clone(); }
    public DaySo(DaySo other) : this(other.a) { }

    // Thuộc tính trả về số lượng phần tử của dãy
    public int Length => a.Length;

    // Chỉ mục (Indexer) để truy xuất hoặc gán phần tử tại vị trí i
    public int this[int i]
    {
        get => a[i];
        set => a[i] = value;
    }

    // Nhập dãy số từ bàn phím
    public void Input()
    {
        int n = Helper.ReadInt("Số phần tử n: ");
        a = new int[n < 0 ? 0 : n];
        for (int i = 0; i < a.Length; i++)
            a[i] = Helper.ReadInt($"  a[{i}] = ");
    }

    // Xuất dãy số ra màn hình (cách nhau bởi khoảng trắng)
    public void Output() => Console.WriteLine(string.Join(" ", a));

    // Tìm và trả về danh sách các số chẵn trong dãy
    public List<int> TimSoChan()
    {
        List<int> kq = new List<int>();
        foreach (int x in a) if (x % 2 == 0) kq.Add(x);
        return kq;
    }
}

// Lớp chạy thử nghiệm (Bài 2.3)
public static class Bai2_3
{
    public static void Run()
    {
        DaySo d = new DaySo();
        d.Input();
        
        Console.Write("Dãy số: "); d.Output();
        
        // Truy xuất phần tử đầu tiên bằng indexer nếu dãy không rỗng
        if (d.Length > 0) Console.WriteLine($"Phần tử đầu tiên (indexer d[0]) = {d[0]}");
        
        // In ra các số chẵn có trong dãy
        Console.WriteLine("Các số chẵn: " + string.Join(" ", d.TimSoChan()));
    }
}