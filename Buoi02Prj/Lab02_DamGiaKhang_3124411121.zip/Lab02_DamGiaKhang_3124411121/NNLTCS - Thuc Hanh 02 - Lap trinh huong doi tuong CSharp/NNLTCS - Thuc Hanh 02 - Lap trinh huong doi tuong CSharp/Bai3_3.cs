namespace BaiTap;

// Delegate dùng để so sánh hai đối tượng
public delegate int SoSanh<T>(T x, T y);
// Lớp thực hiện sắp xếp bằng Delegate
public static class MySorterDelegate
{
      // Hàm sắp xếp mảng
    // cmp là hàm dùng để so sánh hai phần tử
    public static void Sort<T>(T[] a, SoSanh<T> cmp)
    {
        // Duyệt từ phần tử đầu đến phần tử kế cuối
        for (int i = 0; i < a.Length - 1; i++)
        // So sánh với các phần tử phía sau
            for (int j = i + 1; j < a.Length; j++)
            // Nếu phần tử trước lớn hơn phần tử sau thì đổi chỗ
                if (cmp(a[i], a[j]) > 0)
                    (a[i], a[j]) = (a[j], a[i]);
    }
}

// Lớp thực hiện bài 3_3
public static class Bai3_3
{
     // Hàm so sánh hai số theo thứ tự tăng dần
    static int TangDan(int x, int y) => x.CompareTo(y);

    public static void Run()
    {
        // Tạo mảng số nguyên
        int[] so = { 5, 2, 9, 1, 7 };
        // Sắp xếp tăng dần bằng hàm TangDan
        MySorterDelegate.Sort(so, TangDan);
        // Xuất kết quả
        Console.WriteLine("Tăng dần : " + string.Join(" ", so));
         // Sắp xếp giảm dần bằng Lambda
        MySorterDelegate.Sort(so, (x, y) => y.CompareTo(x));   // lambda

        // Xuất kết quả
        Console.WriteLine("Giảm dần : " + string.Join(" ", so));

        // Tạo mảng sinh viên
        SinhVien[] sv =
        {
            new SinhVien("Chi", 9.0), new SinhVien("An", 8.5), new SinhVien("Bình", 6.0)
        };

        // Sắp xếp sinh viên theo tên tăng dần
        MySorterDelegate.Sort(sv, (a, b) => string.Compare(a.HoTen, b.HoTen, StringComparison.CurrentCulture));
         // Xuất danh sách theo tên
        Console.WriteLine("SinhVien theo tên: " + string.Join(", ", sv.Select(s => s.ToString())));
         // Sắp xếp sinh viên theo điểm giảm dần
        MySorterDelegate.Sort(sv, (a, b) => b.Diem.CompareTo(a.Diem));
         // Xuất danh sách theo điểm
        Console.WriteLine("SinhVien theo điểm giảm: " + string.Join(", ", sv.Select(s => s.ToString())));
    }
}
