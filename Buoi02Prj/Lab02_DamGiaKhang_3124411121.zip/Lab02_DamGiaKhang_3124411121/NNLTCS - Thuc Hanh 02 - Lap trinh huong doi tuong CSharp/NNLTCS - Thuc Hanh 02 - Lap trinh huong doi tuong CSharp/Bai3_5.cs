namespace BaiTap;

// Lớp nhân viên trừu tượng
public abstract class NhanVien
{
    // Mã nhân viên
    public string MaNV { get; set; }

    // Họ tên nhân viên
    public string HoTen { get; set; }

    // Nhập thông tin cơ bản của nhân viên
    public virtual void Input()
    {
        MaNV = Helper.ReadString("  Mã nhân viên: ");
        HoTen = Helper.ReadString("  Họ tên: ");
    }

    // Hàm tính lương bắt buộc lớp con phải cài đặt
    public abstract double TinhLuong();

    // Xuất thông tin nhân viên
    public virtual void Output() =>
        Console.WriteLine(
            $"  {MaNV,-8} {HoTen,-20} Lương: {TinhLuong():N0} VNĐ"
        );
}


// Nhân viên kinh doanh kế thừa từ NhanVien
public class NhanVienKinhDoanh : NhanVien
{
    // Lương cơ bản
    public double LuongCoBan { get; set; }

    // Số hợp đồng ký được
    public int SoHopDong { get; set; }

    // Nhập thông tin nhân viên kinh doanh
    public override void Input()
    {
        // Nhập mã nhân viên và họ tên
        base.Input();

        // Nhập lương cơ bản và số hợp đồng
        LuongCoBan = Helper.ReadDouble("  Lương cơ bản: ");
        SoHopDong = Helper.ReadInt("  Số hợp đồng ký được: ");
    }

    // Tính lương nhân viên kinh doanh
    public override double TinhLuong() =>
        LuongCoBan + SoHopDong * 500000;
}


// Nhân viên sản xuất kế thừa từ NhanVien
public class NhanVienSanXuat : NhanVien
{
    // Số sản phẩm làm được
    public int SoSanPham { get; set; }

    // Nhập thông tin nhân viên sản xuất
    public override void Input()
    {
        // Nhập mã nhân viên và họ tên
        base.Input();

        // Nhập số sản phẩm
        SoSanPham = Helper.ReadInt("  Số sản phẩm: ");
    }

    // Tính lương nhân viên sản xuất
    public override double TinhLuong()
    {
        // Mỗi sản phẩm được 1000 đồng
        double luong = SoSanPham * 1000;

        // Nếu sản xuất trên 3000 sản phẩm thì được thêm 5%
        if (SoSanPham > 3000)
            luong *= 1.05;

        return luong;
    }
}


// Lớp thực hiện bài 3_5
public static class Bai3_5
{
    public static void Run()
    {
        // Nhập số lượng nhân viên
        int n = Helper.ReadInt("Số nhân viên: ");

        // Tạo danh sách nhân viên
        List<NhanVien> ds = new List<NhanVien>();

        // Nhập thông tin từng nhân viên
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhân viên {i + 1}:");

            // Nhập loại nhân viên
            int loai;
            do
            {
                loai = Helper.ReadInt(
                    "  Loại (1 = Kinh doanh, 2 = Sản xuất): "
                );
            }
            while (loai != 1 && loai != 2);

            // Tạo đối tượng nhân viên theo loại
            NhanVien nv = loai == 1
                ? new NhanVienKinhDoanh()
                : new NhanVienSanXuat();

            // Nhập thông tin nhân viên
            nv.Input();

            // Thêm nhân viên vào danh sách
            ds.Add(nv);
        }

        // Xuất bảng lương
        Console.WriteLine("Bảng lương:");

        // Gọi Output() tương ứng với từng loại nhân viên
        foreach (var nv in ds)
            nv.Output();   // Đa hình
    }
}