using System.Collections.Generic;
namespace BaiTap;

// Lớp quản lý danh sách các đối tượng Person (dùng List có kiểu an toàn)
public class PersonList
{
    private List<Person> ds = new List<Person>();

    // Các hàm khởi tạo (mặc định và copy constructor sâu)
    public PersonList() { }
    public PersonList(PersonList other)
    {
        foreach (var p in other.ds) ds.Add(new Person(p));
    }

    // Thuộc tính trả về số lượng người trong danh sách
    public int Count => ds.Count;

    // Thêm một người vào danh sách
    public void Add(Person x) => ds.Add(x);

    // Nhập danh sách nhiều người từ bàn phím
    public void Input()
    {
        int n = Helper.ReadInt("Số người: ");
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Người thứ {i + 1}:");
            Person p = new Person();
            p.Input();
            Add(p);
        }
    }

    // Xuất toàn bộ danh sách ra màn hình
    public void Output()
    {
        if (ds.Count == 0) { Console.WriteLine("  (danh sách rỗng)"); return; }
        foreach (var p in ds) p.Output();
    }

    // Lọc ra danh sách những người còn sống (dựa vào phương thức IsLiving của lớp Person)
    public PersonList LivingPeople()
    {
        PersonList kq = new PersonList();
        foreach (var p in ds)
            if (p.IsLiving()) kq.Add(new Person(p));
        return kq;
    }
}

// Lớp chạy thử nghiệm (Bài 2.2)
public static class Bai2_2
{
    public static void Run()
    {
        PersonList pl = new PersonList();
        pl.Input();
        
        Console.WriteLine("Toàn bộ danh sách:");
        pl.Output();
        
        Console.WriteLine("Những người còn sống:");
        pl.LivingPeople().Output();
    }
}