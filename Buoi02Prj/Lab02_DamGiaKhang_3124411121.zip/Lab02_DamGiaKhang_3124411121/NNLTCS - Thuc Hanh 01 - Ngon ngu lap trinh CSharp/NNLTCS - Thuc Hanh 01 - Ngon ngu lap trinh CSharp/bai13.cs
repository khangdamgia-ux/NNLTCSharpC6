using System;

namespace Bai13
{
    //Lớp mô tả thông tin sinh viên
    public class SinhVien
    {
        //Các trường dữ liệu (thuộc tính)
        public string MaSV { get; set; } = string.Empty;
        public string HoTen { get; set; } = string.Empty;
        public string DiaChi { get; set; } = string.Empty;
        public int NamThuMay { get; set; }

        //Constructor không đối số
        public SinhVien() { }

        // Constructor có đối số
        public SinhVien(string maSV, string hoTen, string diaChi, int namThuMay)
        {
            MaSV = maSV;
            HoTen = hoTen;
            DiaChi = diaChi;
            NamThuMay = namThuMay;
        }
        //Phương thức nhập thông tin
        public void Nhap()
        {
            Console.Write("Nhap ma sinh vien: ");
            MaSV = Console.ReadLine()!;

            Console.Write("Nhap ho va ten: ");
            HoTen = Console.ReadLine()!;

            Console.Write("Nhap dia chi: ");
            DiaChi = Console.ReadLine()!;

            Console.Write("Nhap sinh vien nam thu may (1, 2, 3, 4...): ");
            int nam;
            while (!int.TryParse(Console.ReadLine(), out nam) || nam <= 0)
            {
                Console.Write("Gia tri khong hop le! Vui long nhap lai nam hoc: ");
            }
            NamThuMay = nam;
        }
        //Phương thức xuất thông tin
        public void Xuat()
        {
            Console.WriteLine("\n===== THONG TIN SINH VIEN =====");
            Console.WriteLine($"Ma sinh vien : {MaSV}");
            Console.WriteLine($"Ho va ten    : {HoTen}");
            Console.WriteLine($"Dia chi      : {DiaChi}");
            Console.WriteLine($"Sinh vien nam: {NamThuMay}");
            Console.WriteLine("================================");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Khởi tạo một đối tượng sinh viên
            SinhVien sv = new SinhVien();

            Console.WriteLine("--- NHAP THONG TIN SINH VIEN ---");
            sv.Nhap();
            //Hiển thị thông tin vừa nhập
            sv.Xuat();

            Console.ReadKey();
        }
    }
}