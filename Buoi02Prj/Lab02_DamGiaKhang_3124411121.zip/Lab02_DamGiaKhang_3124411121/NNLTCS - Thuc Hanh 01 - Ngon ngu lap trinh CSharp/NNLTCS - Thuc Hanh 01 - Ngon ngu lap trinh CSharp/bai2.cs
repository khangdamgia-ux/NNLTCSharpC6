using System;
namespace Bai2
{
    class Program{
        public static void Main(String[] args){
            Console.WriteLine("Nhap ho ten cua ban");
            String ten=Console.ReadLine();
            Console.WriteLine("Chao ban "+ten);
            Console.ReadKey();
        }
    }
}