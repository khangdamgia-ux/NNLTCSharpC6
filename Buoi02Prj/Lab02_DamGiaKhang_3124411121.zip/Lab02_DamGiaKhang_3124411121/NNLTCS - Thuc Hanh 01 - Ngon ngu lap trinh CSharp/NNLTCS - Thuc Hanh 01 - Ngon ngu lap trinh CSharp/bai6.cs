using System;

namespace Bai6
{
    public class TimMax
    {
        //Dùng lệnh return
        public static int TimMaxReturn(int a, int b, int c)
        {
            int max = a;
            if (b > max) max = b;
            if (c > max) max = c;
            return max;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap so thu nhat (a): ");
            int a = int.Parse(Console.ReadLine()!);

            Console.Write("Nhap so thu hai (b): ");
            int b = int.Parse(Console.ReadLine()!);

            Console.Write("Nhap so thu ba (c): ");
            int c = int.Parse(Console.ReadLine()!);

            Console.WriteLine("\n--- KET QUA ---");

            int max = TimMax.TimMaxReturn(a, b, c);
            Console.WriteLine($"Ket qua Max return : {max}");
        }
    }
}