using System;

namespace Bai4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Nhập và kiểm tra số nguyên x
            Console.Write("Nhap so nguyen x: ");
            bool isXValid = int.TryParse(Console.ReadLine(), out int x);
            if (!isXValid)
            {
                Console.WriteLine("Loi: x phai la mot so nguyen!");
                Console.ReadKey();
                return; 
                //Dừng chương trình nếu x sai
            }
            // Nhập và kiểm tra số nguyên y
            Console.Write("Nhap so nguyen y: ");
            bool isYValid = int.TryParse(Console.ReadLine(), out int y);
            if (!isYValid)
            {
                Console.WriteLine("Loi: y phai la mot so nguyen!");
                Console.ReadKey();
                return; 
                //Dừng chương trình nếu y sai
            }
            //Tính toán và xuất kết quả
            long ketQua = (long)Math.Pow(x, y);
            Console.WriteLine($"Ket qua {x} mu {y} la: {ketQua}");

            Console.ReadKey();
        }
    }
}