using System;

namespace Bai5
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 0, y = 0;
            bool daNhap = false;
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n========== MENU ==========");
                Console.WriteLine("1. Nhap hai gia tri so thuc cho x, y");
                Console.WriteLine("2. Tinh x^y");
                Console.WriteLine("3. Tinh can bac 2 cua x va y");
                Console.WriteLine("4. Thoat");
                Console.WriteLine("==========================");
                Console.Write("Chon chuc nang: ");

                string chon = Console.ReadLine()!;

                switch (chon)
                {
                    case "1":
                        Console.Write("Nhap x: ");
                        while (!double.TryParse(Console.ReadLine(), out x))
                        {
                            Console.Write("Gia tri khong hop le! Nhap lai x: ");
                        }

                        Console.Write("Nhap y: ");
                        while (!double.TryParse(Console.ReadLine(), out y))
                        {
                            Console.Write("Gia tri khong hop le! Nhap lai y: ");
                        }

                        daNhap = true;
                        Console.WriteLine($"-> Da luu: x = {x}, y = {y}");
                        break;

                    case "2":
                        if (!daNhap)
                        {
                            Console.WriteLine("Loi: Vui long chon chuc nang 1 de nhap x, y truoc!");
                            break;
                        }
                        double luyThua = Math.Pow(x, y);
                        Console.WriteLine($"-> Ket qua {x}^{y} = {luyThua}");
                        break;

                    case "3":
                        if (!daNhap)
                        {
                            Console.WriteLine("Loi: Vui long chon chuc nang 1 de nhap x, y truoc!");
                            break;
                        }
                        //Kiem tra dieu kien can bac hai khong am
                        if (x < 0)
                            Console.WriteLine($"-> x = {x} < 0, khong the tinh can bac 2 cua x!");
                        else
                            Console.WriteLine($"-> Can bac 2 cua {x} la: {Math.Sqrt(x)}");

                        if (y < 0)
                            Console.WriteLine($"-> y = {y} < 0, khong the tinh can bac 2 cua y!");
                        else
                            Console.WriteLine($"-> Can bac 2 cua {y} la: {Math.Sqrt(y)}");
                        break;

                    case "4":
                        Console.WriteLine("Tam biet!");
                        running = false;
                        break;

                    default:
                        Console.WriteLine("Lua chon khong hop le! Vui long nhap tu 1 den 4.");
                        break;
                }
            }
        }
    }
}