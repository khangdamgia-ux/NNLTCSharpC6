using System;

namespace Bai8
{
    public class TimMax
    {
        //Dùng từ khóa out
        public static void TimMaxOut(int a, int b, int c, out int max)
        {
            max = a;
            if (b > max) max = b;
            if (c > max) max = c;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap so thu nhat (a): ");
            int a = int.Parse(Console.ReadLine()!);

            Console.Write("Nhap so thu hai (b): ");
            int b = int.Parse(Console.ReadLine()!);

            Console.Write("Nhap so thu ba (c): ");
            int c = int.Parse(Console.ReadLine()!);

            Console.WriteLine("\n--- KET QUA ---");

            TimMax.TimMaxOut(a, b, c, out int max);
            Console.WriteLine($"Ket qua Max out : {max}");

        }
    }
}