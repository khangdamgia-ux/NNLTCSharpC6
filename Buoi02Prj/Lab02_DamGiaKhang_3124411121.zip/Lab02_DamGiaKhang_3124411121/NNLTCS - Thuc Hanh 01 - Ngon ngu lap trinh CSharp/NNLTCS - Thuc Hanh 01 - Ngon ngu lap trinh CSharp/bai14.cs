using System;

namespace Bai14
{
    public class NhanVien
    {
        //Các thuộc tính của nhân viên
        public string HoTen { get; set; } = string.Empty;
        public double MucLuong { get; set; }
        public int SoNgayVang { get; set; }
        //Constructor không tham số
        public NhanVien() { }
        //Constructor có tham số
        public NhanVien(string hoTen, double mucLuong, int soNgayVang)
        {
            HoTen = hoTen;
            MucLuong = mucLuong;
            SoNgayVang = soNgayVang;
        }
        //Phương thức nhập dữ liệu có kiểm tra đầu vào
        public void Nhap()
        {
            Console.Write("Nhap ho ten nhan vien: ");
            HoTen = Console.ReadLine()!;
            //Nhập mức lương (phải là số >= 0)
            Console.Write("Nhap muc luong co ban (VND): ");
            double luong;
            while (!double.TryParse(Console.ReadLine(), out luong) || luong < 0)
            {
                Console.Write("Muc luong khong hop le! Vui long nhap lai: ");
            }
            MucLuong = luong;
            //Nhập số ngày vắng (phải là số nguyên >= 0)
            Console.Write("Nhap so ngay vang: ");
            int ngayVang;
            while (!int.TryParse(Console.ReadLine(), out ngayVang) || ngayVang < 0)
            {
                Console.Write("So ngay vang khong hop le! Vui long nhap lai: ");
            }
            SoNgayVang = ngayVang;
        }
        //Phương thức tính lương thực lãnh
        //Mỗi ngày vắng bị trừ 100.000 VNĐ, lương thực lãnh tối thiểu là 0
        public double TinhLuongThucLanh()
        {
            double tienTru = SoNgayVang * 100000.0;
            double luongThucLanh = MucLuong - tienTru;

            return luongThucLanh > 0 ? luongThucLanh : 0;
        }
        //Phương thức xuất thông tin chi tiết
        public void Xuat()
        {
            Console.WriteLine("\n===== THONG TIN LUONG NHAN VIEN =====");
            Console.WriteLine($"Ho ten           : {HoTen}");
            Console.WriteLine($"Muc luong co ban : {MucLuong:#,##0} VND");
            Console.WriteLine($"So ngay vang     : {SoNgayVang} ngay");
            Console.WriteLine($"Tien bi tru      : {SoNgayVang * 100000:#,##0} VND");
            Console.WriteLine($"Luong thuc lanh  : {TinhLuongThucLanh():#,##0} VND");
            Console.WriteLine("=====================================");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            NhanVien nv = new NhanVien();

            Console.WriteLine("--- NHAP THONG TIN NHAN VIEN ---");
            nv.Nhap();
            //Hiển thị kết quả tính lương
            nv.Xuat();

            Console.ReadKey();
        }
    }
}