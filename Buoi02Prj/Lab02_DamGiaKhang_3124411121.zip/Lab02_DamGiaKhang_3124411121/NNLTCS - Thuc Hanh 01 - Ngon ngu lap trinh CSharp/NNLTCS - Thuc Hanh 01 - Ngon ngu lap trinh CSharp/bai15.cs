using System;
using System.Collections.Generic;

namespace Bai15
{
    public class MangSoNguyen
    {
        //Thuộc tính lưu trữ mảng
        private int[] arr = Array.Empty<int>();

        //Phương thức thành viên: Nhập mảng gồm n phần tử
        public void NhapMang()
        {
            int n;
            Console.Write("Nhap so luong phan tu n (n > 0): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Gia tri khong hop le! Vui long nhap lai n: ");
            }

            arr = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhap phan tu arr[{i}]: ");
                while (!int.TryParse(Console.ReadLine(), out arr[i]))
                {
                    Console.Write($"Gia tri khong hop le! Nhap lai arr[{i}]: ");
                }
            }
        }

        //Phương thức thành viên: In mảng ra màn hình
        public void InMang()
        {
            if (arr.Length == 0)
            {
                Console.WriteLine("Mang rong!");
                return;
            }

            Console.WriteLine(string.Join(" ", arr));
        }

        //Phương thức thành viên: Tìm phần tử lớn nhất và nhỏ nhất trong mảng (dùng out)
        public void TimMaxMin(out int max, out int min)
        {
            if (arr.Length == 0)
            {
                throw new InvalidOperationException("Mang chua co phan tu nao!");
            }

            max = arr[0];
            min = arr[0];

            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] > max) max = arr[i];
                if (arr[i] < min) min = arr[i];
            }
        }

        //Hàm phụ trợ kiểm tra số nguyên tố
        private bool KiemTraNguyenTo(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i * i <= n; i++)
            {
                if (n % i == 0) return false;
            }
            return true;
        }

        //Phương thức thành viên: Trả về mảng các số nguyên tố
        public int[] LayCacSoNguyenTo()
        {
            List<int> dsNguyenTo = new List<int>();

            foreach (int x in arr)
            {
                if (KiemTraNguyenTo(x))
                {
                    dsNguyenTo.Add(x);
                }
            }

            return dsNguyenTo.ToArray();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MangSoNguyen mang = new MangSoNguyen();

            //Nhập mảng
            Console.WriteLine("=== 1. NHAP MANG ===");
            mang.NhapMang();

            //In mảng
            Console.WriteLine("\n=== 2. MANG VUA NHAP ===");
            mang.InMang();

            //Tìm Max và Min
            mang.TimMaxMin(out int max, out int min);
            Console.WriteLine("\n=== 3. PHAN TU LON NHAT VA NHO NHAT ===");
            Console.WriteLine($"Phan tu lon nhat (Max): {max}");
            Console.WriteLine($"Phan tu nho nhat (Min): {min}");

            //Mảng số nguyên tốx    
            int[] mangSNT = mang.LayCacSoNguyenTo();
            Console.WriteLine("\n=== 4. CAC SO NGUYEN TO TRONG MANG ===");
            if (mangSNT.Length > 0)
            {
                Console.WriteLine(string.Join(" ", mangSNT));
            }
            else
            {
                Console.WriteLine("Khong co so nguyen to nao trong mang.");
            }

            Console.ReadKey();
        }
    }
}