using System;

namespace Bai7
{
    public class KiemTraSo
    {
        //Phương thức bool kiểm tra số nguyên tố
        //Trả về true nếu là số nguyên tố, ngược lại trả về false
        public static bool LaSoNguyenTo(int n)
        {
            if (n < 2)
            {
                return false;
            }

            //Kiểm tra các ước từ 2 đến căn bậc hai của n
            for (int i = 2; i * i <= n; i++)
            {
                if (n % i == 0)
                {
                    return false; //Tìm thấy ước số khác 1 và chính nó -> không phải SNT
                }
            }

            return true; //Không tìm thấy ước nào -> là SNT
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap vao so nguyen n: ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n))
            {
                Console.Write("Gia tri khong hop le! Vui long nhap lai so nguyen n: ");
            }

            //Gọi phương thức bool và kiểm tra kết quả trả về
            if (KiemTraSo.LaSoNguyenTo(n))
            {
                Console.WriteLine($"{n} la so nguyen to.");
            }
            else
            {
                Console.WriteLine($"{n} khong phai la so nguyen to.");
            }
            Console.ReadKey();
        }
    }
}