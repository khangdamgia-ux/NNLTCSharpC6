using System;

namespace Bai10
{
    public class KiemTraChuoi
    {
        //Thuộc tính lưu trữ chuỗi
        private string noiDung;

        //Constructor khởi tạo
        public KiemTraChuoi(string noiDung)
        {
            this.noiDung = noiDung;
        }
        //Phương thức thành viên kiểm tra chuỗi có đối xứng hay không
        public bool LaDoiXung()
        {
            if (string.IsNullOrEmpty(noiDung))
                return true;

            int left = 0;
            int right = noiDung.Length - 1;
            while (left < right)
            {
                //So sánh từng cặp ký tự từ ngoài vào trong
                if (noiDung[left] != noiDung[right])
                {
                    //Phát hiện khác nhau -> không đối xứng
                    return false; 
                }
                left++;
                right--;
            }
            //Khớp toàn bộ -> đối xứng
              return true; 
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap chuoi can kiem tra: ");
            string input = Console.ReadLine()!;
            //Khởi tạo đối tượng và gọi phương thức thành viên
            
            KiemTraChuoi obj = new KiemTraChuoi(input);

            if (obj.LaDoiXung())
            {
                Console.WriteLine($"Chuoi \"{input}\" la chuoi doi xung (Palindrome).");
            }
            else
            {
                Console.WriteLine($"Chuoi \"{input}\" khong phai la chuoi doi xung.");
            }

            Console.ReadKey();
        }
    }
}