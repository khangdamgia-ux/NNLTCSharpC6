using System;

namespace Bai12
{
    public class XuLyChuoi
    {
        private string noiDung;

        public XuLyChuoi(string noiDung)
        {
            this.noiDung = noiDung;
        }
        //Chuyển sang ký tự thường
        public string ChuyenThuong()
        {
            return noiDung.ToLower();
        }
        //Chuyển sang ký tự hoa
        public string ChuyenHoa()
        {
            return noiDung.ToUpper();
        }
        //Đếm số từ trong chuỗi
        public int DemSoTu()
        {
            if (string.IsNullOrWhiteSpace(noiDung))
                return 0;
            //Tách các từ dựa trên khoảng trắng, loại bỏ các phần tử rỗng
            string[] cacTu = noiDung.Split(new char[] { ' ', '\t', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return cacTu.Length;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap chuoi: ");
            string input = Console.ReadLine()!;

            XuLyChuoi xl = new XuLyChuoi(input);

            Console.WriteLine("\n--- KET QUA ---");
            Console.WriteLine($"Chuoi chu thuong : {xl.ChuyenThuong()}");
            Console.WriteLine($"Chuoi chu hoa    : {xl.ChuyenHoa()}");
            Console.WriteLine($"So tu trong chuoi : {xl.DemSoTu()}");

            Console.ReadKey();
        }
    }
}