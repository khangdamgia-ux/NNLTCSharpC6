using System;

namespace Bai11
{
    public class XuLyChuoi
    {
        //Thuộc tính lưu trữ chuỗi ban đầu
        private string noiDung;
        //Constructor khởi tạo
        public XuLyChuoi(string noiDung)
        {
            this.noiDung = noiDung;
        }
        //Phương thức thành viên trả về chuỗi đảo ngược
        public string DaoNguoc()
        {
            if (string.IsNullOrEmpty(noiDung))
                return noiDung;
            //Chuyển chuỗi thành mảng ký tự để đảo ngược
            char[] mangKyTu = noiDung.ToCharArray();
            Array.Reverse(mangKyTu);
            //Tạo chuỗi mới từ mảng đã đảo và trả về
            return new string(mangKyTu);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap chuoi can dao nguoc: ");
            string input = Console.ReadLine()!;
            //Khởi tạo đối tượng với chuỗi vừa nhập
            XuLyChuoi chuoiObj = new XuLyChuoi(input);
            //Gọi phương thức thành viên để lấy kết quả đảo ngược
            string chuoiDao = chuoiObj.DaoNguoc();

            Console.WriteLine($"Chuoi ban dau: {input}");
            Console.WriteLine($"Chuoi sau khi dao nguoc: {chuoiDao}");

            Console.ReadKey();
        }
    }
}