using System;

namespace Bai3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Nhap so nguyen dau tien
            Console.Write("Nhap so nguyen x: ");
            int x = int.Parse(Console.ReadLine());
            //Nhap so nguyen thu hai
            Console.Write("Nhap so nguyen y: ");
            int y = int.Parse(Console.ReadLine());
            long ketQua = (long)Math.Pow(x, y);
            Console.WriteLine($"Ket qua {x} mu {y} la: {ketQua}");

            Console.ReadKey();
        }
    }
}