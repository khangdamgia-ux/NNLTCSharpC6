using System;

namespace Bai9
{
    //Dùng từ khóa ref
    public class TimMax
    {
        public static void TimMaxRef(int a, int b, int c, ref int max)
        {
            max = a;
            if (b > max) max = b;
            if (c > max) max = c;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap so thu nhat (a): ");
            int a = int.Parse(Console.ReadLine()!);

            Console.Write("Nhap so thu hai (b): ");
            int b = int.Parse(Console.ReadLine()!);

            Console.Write("Nhap so thu ba (c): ");
            int c = int.Parse(Console.ReadLine()!);

            Console.WriteLine("\n--- KET QUA ---");
            
            int max = 0;
            TimMax.TimMaxRef(a, b, c, ref max);
            Console.WriteLine($"Ket qua Max ref: {max}");

            Console.ReadKey();
        }
    }
}