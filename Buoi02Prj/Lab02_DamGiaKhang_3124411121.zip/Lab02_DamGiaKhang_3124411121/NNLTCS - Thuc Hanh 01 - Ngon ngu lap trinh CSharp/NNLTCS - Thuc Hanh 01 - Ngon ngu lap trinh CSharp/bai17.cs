using System;
using System.Collections.Generic;

namespace Bai17
{
    public class MaTran
    {
        private int[,] a = new int[0, 0];
        private int n; //Số dòng
        private int m; //Số cột

        //Phương thức sinh ngẫu nhiên mảng A[nxm] trong đoạn [10, 100]
        public void SinhNgauNhien()
        {
            Console.Write("Nhap so dong n (n > 0): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Gia tri khong hop le! Nhap lai so dong n: ");
            }

            Console.Write("Nhap so cot m (m > 0): ");
            while (!int.TryParse(Console.ReadLine(), out m) || m <= 0)
            {
                Console.Write("Gia tri khong hop le! Nhap lai so cot m: ");
            }

            a = new int[n, m];
            Random rand = new Random();

            //rand.Next(10, 101) sẽ sinh số trong đoạn [10, 100] (cận trên 101 không lấy)
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    a[i, j] = rand.Next(10, 101);
                }
            }
            Console.WriteLine($"-> Da sinh ngau nhien ma tran {n}x{m} trong doan [10, 100].");
        }

        //Phương thức in mảng 2 chiều ra màn hình theo dạng lưới
        public void InMang()
        {
            if (a.Length == 0)
            {
                Console.WriteLine("Ma tran rong!");
                return;
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write($"{a[i, j],5}"); // Căn lề mỗi số 5 ký tự cho thẳng hàng
                }
                Console.WriteLine();
            }
        }

        //Phương thức trả về hai mảng: mảng các số chẵn và mảng các số lẻ (sử dụng out)
        public void TachChanLe(out int[] mangChan, out int[] mangLe)
        {
            List<int> dsChan = new List<int>();
            List<int> dsLe = new List<int>();

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    if (a[i, j] % 2 == 0)
                    {
                        dsChan.Add(a[i, j]);
                    }
                    else
                    {
                        dsLe.Add(a[i, j]);
                    }
                }
            }

            mangChan = dsChan.ToArray();
            mangLe = dsLe.ToArray();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MaTran mt = new MaTran();

            //Sinh ngẫu nhiên ma trận
            Console.WriteLine("=== 1. KHOI TAO MA TRAN ===");
            mt.SinhNgauNhien();

            //In ma trận
            Console.WriteLine("\n=== 2. MA TRAN DUOC SINH ===");
            mt.InMang();

            //Tách và xuất mảng chẵn / lẻ
            mt.TachChanLe(out int[] mangChan, out int[] mangLe);

            Console.WriteLine("\n=== 3. KET QUA TACH MANG ===");
            Console.WriteLine($"Mang so chan ({mangChan.Length} phan tu):");
            Console.WriteLine(mangChan.Length > 0 ? string.Join(" ", mangChan) : "Khong co so chan nao.");

            Console.WriteLine($"\nMang so le ({mangLe.Length} phan tu):");
            Console.WriteLine(mangLe.Length > 0 ? string.Join(" ", mangLe) : "Khong co so le nao.");

            Console.ReadKey();
        }
    }
}