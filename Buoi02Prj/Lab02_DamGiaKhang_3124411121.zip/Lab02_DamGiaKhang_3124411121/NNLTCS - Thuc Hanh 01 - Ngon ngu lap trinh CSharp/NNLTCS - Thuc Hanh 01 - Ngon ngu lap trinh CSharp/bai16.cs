using System;

namespace Bai16
{
    public class DanhSachHoTen
    {
        //Mảng lưu trữ danh sách họ tên
        private string[] dsHoTen = Array.Empty<string>();

        //Phương thức thành viên: Nhập mảng gồm n người
        public void Nhap()
        {
            int n;
            Console.Write("Nhap so luong nguoi n (n > 0): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Gia tri khong hop le! Vui long nhap lai n: ");
            }

            dsHoTen = new string[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhap ho ten nguoi thu {i + 1}: ");
                string? input = Console.ReadLine();
                //Nếu người dùng nhập rỗng thì gán chuỗi rỗng để tránh null
                dsHoTen[i] = string.IsNullOrWhiteSpace(input) ? "" : input.Trim();
            }
        }

        // Phương thức thành viên: Sắp xếp mảng theo thứ tự tăng dần (A -> Z)
        public void SapXepTangDan()
        {
            //Sử dụng hàm có sẵn của C#
            Array.Sort(dsHoTen, StringComparer.CurrentCultureIgnoreCase);
        }

        //Phương thức thành viên: Xuất danh sách họ tên
        public void Xuat()
        {
            if (dsHoTen.Length == 0)
            {
                Console.WriteLine("Danh sach rong!");
                return;
            }

            for (int i = 0; i < dsHoTen.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {dsHoTen[i]}");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            DanhSachHoTen ds = new DanhSachHoTen();

            Console.WriteLine("=== NHAP DANH SACH HO TEN ===");
            ds.Nhap();

            Console.WriteLine("\n=== DANH SACH BAN DAU ===");
            ds.Xuat();

            //Thực hiện sắp xếp tăng dần
            ds.SapXepTangDan();

            Console.WriteLine("\n=== DANH SACH SAU KHI SAP XEP TANG DAN ===");
            ds.Xuat();

            Console.ReadKey();
        }
    }
}