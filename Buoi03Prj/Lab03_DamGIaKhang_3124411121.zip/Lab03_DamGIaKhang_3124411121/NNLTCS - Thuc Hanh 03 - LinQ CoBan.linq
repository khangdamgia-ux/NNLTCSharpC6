<Query Kind="Program" />

using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThuHanhLINQ
{
    public class MonHoc
    {
        public string MaMon { get; set; } = "";
        public string TenMon { get; set; } = "";
        public string He { get; set; } = "";
        public byte SoTiet { get; set; }
    }

    public class He
    {
        public string MaHe { get; set; } = "";
        public string TenHe { get; set; } = "";
    }

    public static class DuLieu
    {
        public static List<MonHoc> DS_Mon()
        {
            return new List<MonHoc>
            {
                new MonHoc { MaMon = "HP2_1", TenMon = "Nền tảng C#", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP2_2", TenMon = "Công nghệ ADO.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_1", TenMon = "Lập trình Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP3_2", TenMon = "Xây dựng ứng dụng Windows Forms", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_1", TenMon = "Lập trình Web với HTML, CSS và JavaScript", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP4_2", TenMon = "Xây dựng ứng dụng Web với ASP.NET", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_1", TenMon = "Lập trình CSDL SQL Server căn bản", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "HP5_2", TenMon = "Lập trình CSDL SQL Server nâng cao", He = "KTV", SoTiet = 64 },
                new MonHoc { MaMon = "JLCB", TenMon = "Joomla cơ bản", He = "CD", SoTiet = 72 },
                new MonHoc { MaMon = "LINQ", TenMon = "Language-Integrated Query", He = "CD", SoTiet = 64 },
                new MonHoc { MaMon = "DAWEB", TenMon = "Đồ án thực tế Web với ASP.NET", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "DAWIN", TenMon = "Đồ án thực tế Windows Forms", He = "CD", SoTiet = 40 },
                new MonHoc { MaMon = "CC++", TenMon = "Lập trình hướng đối tượng với C/C++", He = "CD", SoTiet = 128 },
                new MonHoc { MaMon = "JQUE", TenMon = "JQuery", He = "CD", SoTiet = 22 },
                new MonHoc { MaMon = "XML", TenMon = "Công nghệ XML", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "CRYS", TenMon = "Crystal Report trong Visual Studio", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "BWEB", TenMon = "HTML, CSS và JavaScript", He = "CD", SoTiet = 32 },
                new MonHoc { MaMon = "XYZ", TenMon = "Chưa đặt tên môn", He = "", SoTiet = 0 }
            };
        }

        public static List<He> DS_He()
        {
            return new List<He>
            {
                new He { MaHe = "KTV", TenHe = "Kỹ thuật viên" },
                new He { MaHe = "CD", TenHe = "Chuyên đề" },
                new He { MaHe = "QT", TenHe = "Chứng chỉ quốc tế" }
            };
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Console.OutputEncoding = System.Text.Encoding.UTF8;

            Bai21();
            Bai22();
            Bai31();
            Bai32();
            Bai51();
            Bai52();
            Bai62();

            Console.WriteLine("\n--- HOÀN TẤT THỰC HÀNH LINQ ---");
            //Console.ReadKey();
        }

        static void Bai21()
        {
            Console.WriteLine("=== BÀI 2.1: Truy vấn mảng số nguyên ===");
            int[] mangSo = { 50, 42, 16, 3, 9, 8, 12, 7, 24, 0 };

            var a = mangSo.Where(x => x % 12 == 0);
            Console.WriteLine("a. Chia hết cho 4 và 3: " + string.Join(", ", a));

            var b = mangSo.Where(x => x <= 3);
            Console.WriteLine("b. Nhỏ hơn hoặc bằng 3: " + string.Join(", ", b));

            var c = mangSo.Select(x => x % 2 == 0 ? x / 2 : x);
            Console.WriteLine("c. Dãy mới: " + string.Join(", ", c));
            Console.WriteLine();
        }

        static void Bai22()
        {
            Console.WriteLine("=== BÀI 2.2: Truy vấn mảng chuỗi ===");
            string[] mangChuoi = { "đầu", "lòng", "hai", "ả", "tố", "nga", "Thúy", "Kiều", "là", "chị", "em", "là", "Thúy", "Vân" };

            var a = mangChuoi.Where(s => s.Length == 4).OrderBy(s => s[0]);
            Console.WriteLine("a. Phần tử 4 ký tự: " + string.Join(", ", a));

            var b = mangChuoi.Select(s => $"{s.ToLower()} - {s.ToUpper()}");
            Console.WriteLine("b. Biến đổi:\n   " + string.Join("\n   ", b));

            var c = mangChuoi.Where(s => s.Contains("u"));
            Console.WriteLine("c. Chứa ký tự 'u': " + string.Join(", ", c));

            var d = mangChuoi.Where(s => char.IsUpper(s[0]));
            Console.WriteLine("d. Bắt đầu bằng chữ in hoa: " + string.Join(" ", d));
            Console.WriteLine();
        }

        static void Bai31()
        {
            Console.WriteLine("=== BÀI 3.1: Thống kê mảng số ===");
            int[] mangSo = { 50, 42, 12, 3, 9, 8, 1, 50, 3, 42, 85 };

            Console.WriteLine($"a. Tổng số phần tử: {mangSo.Count()}, Chẵn: {mangSo.Count(x => x % 2 == 0)}, Lẻ: {mangSo.Count(x => x % 2 != 0)}");
            Console.WriteLine($"b. Tổng giá trị: {mangSo.Sum()}, Max: {mangSo.Max()}, Min: {mangSo.Min()}");
            Console.WriteLine($"c. Số giá trị khác nhau: {mangSo.Distinct().Count()}");

            Console.WriteLine("d. Phân nhóm theo số dư chia 5:");
            var groups = mangSo.GroupBy(x => x % 5);
            foreach (var g in groups)
                Console.WriteLine($"   Số dư {g.Key}: {string.Join(", ", g)}");
            Console.WriteLine();
        }

        static void Bai32()
        {
            Console.WriteLine("=== BÀI 3.2: Thống kê mảng chuỗi ===");
            string[] monAn = { "Bún bò Huế", "Hủ tiếu heo", "Bánh canh", "Bánh mì",
                "Nước Cà phê", "Mì quảng", "Cơm tấm", "Nước Chanh dây", "Mì xào",
                "Bún riêu", "Bánh cuốn", "Mì gói", "Bún chả", "Hủ tiếu Nam vang" };

            int minLen = monAn.Min(s => s.Length);
            int maxLen = monAn.Max(s => s.Length);
            Console.WriteLine($"a. Món ngắn nhất ({minLen} ký tự): " + string.Join(", ", monAn.Where(s => s.Length == minLen)));
            Console.WriteLine($"   Món dài nhất ({maxLen} ký tự): " + string.Join(", ", monAn.Where(s => s.Length == maxLen)));

            Console.WriteLine("b. Phân nhóm theo từ đầu tiên:");
            var groups = monAn.GroupBy(s => s.Split(' ')[0]);
            foreach (var g in groups)
                Console.WriteLine($"   - [{g.Key}]: {string.Join(", ", g)}");

            Console.WriteLine($"c. Số món bắt đầu bằng 'Bánh': {monAn.Count(s => s.StartsWith("Bánh"))}");
            Console.WriteLine();
        }

        static void Bai51()
        {
            Console.WriteLine("=== BÀI 5.1: Truy vấn cơ bản List ===");
            var ds = DuLieu.DS_Mon();

            var a = ds.Where(m => m.TenMon.StartsWith("Lập trình"));
            Console.WriteLine("a. Môn bắt đầu bằng 'Lập trình': " + string.Join(", ", a.Select(m => m.TenMon)));

            var b = ds.Where(m => m.He == "CD").OrderByDescending(m => m.SoTiet).ThenBy(m => m.MaMon);
            Console.WriteLine("b. Môn hệ 'CD': " + string.Join(", ", b.Select(m => m.MaMon)));

            var c = ds.Where(m => m.TenMon.ToLower().Contains("web")).Select(m => new { m.TenMon, m.He });
            Console.WriteLine("c. Môn chứa từ 'web': " + string.Join(", ", c.Select(x => x.TenMon)));
            Console.WriteLine();
        }

        static void Bai52()
        {
            Console.WriteLine("=== BÀI 5.2: Thống kê trên List ===");
            var ds = DuLieu.DS_Mon();

            Console.WriteLine($"a. Tổng số môn: {ds.Count}");
            Console.WriteLine($"b. Số môn bắt đầu bằng 'Lập trình': {ds.Count(m => m.TenMon.StartsWith("Lập trình"))}");
            Console.WriteLine($"c. Tổng số tiết hệ KTV: {ds.Where(m => m.He == "KTV").Sum(m => m.SoTiet)}");

            Console.WriteLine("d. Tổng số môn của mỗi hệ:");
            foreach (var g in ds.GroupBy(m => m.He))
                Console.WriteLine($"   Hệ '{g.Key}': {g.Count()} môn");

            byte maxTiet = ds.Max(m => m.SoTiet);
            Console.WriteLine("f. Môn học có số tiết cao nhất:");
            foreach (var m in ds.Where(x => x.SoTiet == maxTiet))
                Console.WriteLine($"   - {m.TenMon} ({m.SoTiet} tiết)");
            Console.WriteLine();
        }

        static void Bai62()
        {
            Console.WriteLine("=== BÀI 6.2: Join và các toán tử tập hợp ===");
            var dsMon = DuLieu.DS_Mon();
            var dsHe = DuLieu.DS_He();

            var a = from m in dsMon
                    join h in dsHe on m.He equals h.MaHe
                    select new { h.TenHe, m.MaMon, m.TenMon };

            Console.WriteLine("a. Kết quả Join hệ và môn học:");
            foreach (var item in a.Take(5))
                Console.WriteLine($"   - Hệ: {item.TenHe} | Mã: {item.MaMon} | Tên: {item.TenMon}");

            var b = from h in dsHe
                    join m in dsMon on h.MaHe equals m.He into hmGroup
                    from m in hmGroup.DefaultIfEmpty()
                    select new { h.TenHe, TenMon = m?.TenMon ?? "(Chưa có môn)" };

            Console.WriteLine("b. Left Outer Join:");
            foreach (var item in b)
                Console.WriteLine($"   - Hệ: {item.TenHe} ---> Môn: {item.TenMon}");
            Console.WriteLine();
        }
    }
}